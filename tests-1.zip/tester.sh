#!/bin/bash

TESTS_TO_RUN=1000
EXECUTABLE=./prog

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

shopt -s nullglob
FAILED_TESTS=""

if ! g++ -std=c++11 -DNDEBUG -Wall *.cpp -o $EXECUTABLE; then
  echo "Compilation Failed"
  exit 1
fi

for i in inFiles/test*.in; do
  if [ "${i//[^0-9]/}" -gt $TESTS_TO_RUN ]; then
    continue
  fi

  printf "test $i >>>  "
  $EXECUTABLE <"$i" >outFiles/test"${i//[^0-9]/}".result
  diff outFiles/test"${i//[^0-9]/}".out outFiles/test"${i//[^0-9]/}".result

  if [ $? -eq 0 ]; then
    printf "Test: ${GREEN}pass${NC},   "
  else
    printf "Test: ${RED}fail${NC},   "
    FAILED_TESTS+='-'
    FAILED_TESTS+='F'
  fi
  valgrind --log-file=$i.valgrind_log --leak-check=full $EXECUTABLE <$i 1>/dev/null 2>/dev/null
  if [ -f $i.valgrind_log ]; then
    cat $i.valgrind_log | grep "ERROR SUMMARY: 0" >/dev/null
    if [ $? -eq 0 ]; then
      printf "Leak: ${GREEN}pass${NC}\n"
    else
      printf "Leak: ${RED}fail${NC}\n"
      cat "$i".valgrind_log
      FAILED_TESTS+="-"
    fi
  else
    printf "Leak: ${RED}couldnt get valgrind file${NC}\n"
    FAILED_TESTS+="-"
  fi
  rm "$i".valgrind_log
done

if [ -z ${FAILED_TESTS} ]; then
  printf "\n${GREEN} All tests passed :)${NC}\n\n"
else
  printf "\n${RED} Failed ${FAILED_TESTS}${NC} tests.\n\n"
fi
